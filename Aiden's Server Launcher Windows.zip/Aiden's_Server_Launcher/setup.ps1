# Filename: Install-Python3137-WithRequests.ps1

# Define variables
$pythonUrl = "https://www.python.org/ftp/python/3.13.7/python-3.13.7-amd64.exe"
$installerPath = "$env:TEMP\\python-3.13.7-amd64.exe"

Write-Host "Downloading Python 3.13.7 installer..."
Invoke-WebRequest -Uri $pythonUrl -OutFile $installerPath

Write-Host "Installing Python 3.13.7 silently..."
Start-Process -FilePath $installerPath -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0" -Wait

Start-Process powershell -ArgumentList "NoProfile -ExecutionPolicy Bypass -File `"$PWD\PostInstall.ps1`"" -Wait

# Verify Python installation
Write-Host "`nVerifying Python version:"
python3 --version

# Ensure pip is available (should be by default, but just in case)
Write-Host "`nEnsuring pip is installed..."
python -m ensurepip --upgrade

# Upgrade pip to the latest version
Write-Host "`nUpgrading pip..."
python -m pip install --upgrade pip

# Install requests module
Write-Host "`nInstalling 'requests' package..."
python -m pip install requests

# Final check
Write-Host "`nInstalled packages:"
python -m pip list | findstr requests

Write-Host "`n✅ Python 3.13.7 and 'requests' have been successfully installed."
