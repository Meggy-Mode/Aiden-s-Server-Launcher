#!/bin/bash

# Exit if any command fails
set -e

PYTHON_VERSION="3.13.7"
PYTHON_PKG="python-${PYTHON_VERSION}-macos11.pkg"
PYTHON_URL="https://www.python.org/ftp/python/${PYTHON_VERSION}/${PYTHON_PKG}"
INSTALLER_PATH="/tmp/${PYTHON_PKG}"

# Detect existing python3
if command -v python3 >/dev/null 2>&1; then
    INSTALLED_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    echo "🐍 Found Python $INSTALLED_VERSION already installed."

    if [[ "$INSTALLED_VERSION" == "$PYTHON_VERSION" ]]; then
        echo "✅ Required Python version ${PYTHON_VERSION} is already installed. Skipping installation."
    else
        echo "⚠️  Python version mismatch. Installing Python ${PYTHON_VERSION}..."
        curl -L "$PYTHON_URL" -o "$INSTALLER_PATH"
        sudo installer -pkg "$INSTALLER_PATH" -target /
    fi
else
    echo "📥 Python not found. Installing Python ${PYTHON_VERSION}..."
    curl -L "$PYTHON_URL" -o "$INSTALLER_PATH"
    sudo installer -pkg "$INSTALLER_PATH" -target /
fi

# Refresh PATH in this session
hash -r

# Pick the correct python binary
PYTHON=$(/usr/local/bin/python3 --version >/dev/null 2>&1 && echo "/usr/local/bin/python3" || echo "/usr/bin/python3")

# Verify Python installation
echo
echo "🐍 Using Python:"
$PYTHON --version

# Ensure pip is available
echo
echo "📦 Ensuring pip is installed..."
$PYTHON -m ensurepip --upgrade || true

# Upgrade pip
echo
echo "⬆️  Upgrading pip..."
$PYTHON -m pip install --upgrade pip

# Install requests
echo
echo "🌐 Installing 'requests'..."
$PYTHON -m pip install requests

# Final check
echo
echo "✅ Installed packages:"
$PYTHON -m pip list | grep requests

# Find directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Run a file in the same folder (change filename here)
TARGET_FILE="$SCRIPT_DIR/main.py"

if [[ -f "$TARGET_FILE" ]]; then
    echo
    echo "🚀 Running $TARGET_FILE..."
    $PYTHON "$TARGET_FILE"
else
    echo
    echo "⚠️  No file named 'main.py' found in $SCRIPT_DIR, please contact Aiden about this issue"
fi

echo
echo "🎉 Done!"
read -p "Press [Enter] to continue..."
