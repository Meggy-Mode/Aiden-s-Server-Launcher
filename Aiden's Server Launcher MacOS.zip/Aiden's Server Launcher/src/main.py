import tkinter as tk
import requests
import subprocess
import zipfile
import os
import json

sldrVal = 4000

def slider_to_entry(value):
    """Update entry when slider moves."""
    entry_var.set(value)
    global sldrVal
    sldrVal = value

def entry_to_slider(*args):
    """Update slider when entry changes."""
    try:
        value = int(entry_var.get())
        if 4000 <= value <= 8000:  # match slider range
            slider.set(value)
            global sldrVal
            sldrVal = value
    except ValueError:
        pass


# Define a folder for all downloaded files on the Desktop
DOWNLOAD_FOLDER = os.path.join(os.path.expanduser("~/Desktop"), "ServerLauncher")
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)  # Create folder if it doesn't exist

def download_files(get_url, local_name):
    local_path = os.path.join(DOWNLOAD_FOLDER, local_name)
    try:
        response = requests.get(get_url)
        if response.status_code == 200:
            with open(local_path, 'wb') as f:
                f.write(response.content)
            print(f"File '{local_name}' downloaded successfully to '{DOWNLOAD_FOLDER}'.")
            return local_path
        else:
            print(f"Failed to download file. Status code: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"An error occurred during the request: {e}")
        return None

def unzip_file(zip_path, extract_to=DOWNLOAD_FOLDER):
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        print(f"Extracted '{zip_path}' to '{extract_to}'")
        return True
    except zipfile.BadZipFile as e:
        print(f"Failed to unzip file: {e}")
        return False

def download_extract_and_run_mindustry():
    # Step 1: Download main.zip
    zip_file = download_files(
        "https://github.com/Meggy-Mode/ServerInfo/archive/refs/heads/main.zip",
        "main.zip"
    )
    if not zip_file:
        return

    # Step 2: Extract main.zip
    if not unzip_file(zip_file):
        return

       # Step 3: Extract mindustry-server.zip inside ServerInfo-main
    server_info_path = os.path.join(DOWNLOAD_FOLDER, "ServerInfo-main")
    inner_zip_path = os.path.join(server_info_path, "mindustry-server.zip")
    extract_path = os.path.join(server_info_path, "mindustry-server")  # force folder

    if not os.path.exists(inner_zip_path):
        print(f"Could not find mindustry-server.zip in {server_info_path}")
        return

    if not unzip_file(inner_zip_path, extract_path):
        return


    #if not unzip_file(inner_zip_path):
     #   return

    # Step 4: Run server.jar inside mindustry-server folder
    mindustry_server_path = os.path.join(server_info_path, "mindustry-server")
    jar_file = os.path.join(mindustry_server_path, "server.jar")
    if os.path.exists(jar_file):
        try:
            global sldrVal
            subprocess.Popen(["java", "-Xms2g", "-Xmx" + str(sldrVal) + "m", "-jar", jar_file])
            print(f"Running '{jar_file}'")
        except Exception as e:
            print(f"Failed to run server.jar: {e}")
    else:
        print(f"Could not find server.jar inside {mindustry_server_path}")


def download_unzip_and_run():
    zip_file = download_files(
        "https://github.com/Meggy-Mode/ServerInfo/archive/refs/heads/main.zip", 
        "main.zip"
    )
    if zip_file and unzip_file(zip_file):
        download_extract_and_run_mindustry()

def download_and_run_minecraft():
    # Create a dedicated folder for the Minecraft server
    minecraft_folder = os.path.join(DOWNLOAD_FOLDER, "Minecraft")
    os.makedirs(minecraft_folder, exist_ok=True)

    # Download the server.jar into that folder
    jar_file_path = os.path.join(minecraft_folder, "server.jar")
    url = "https://piston-data.mojang.com/v1/objects/6bce4ef400e4efaa63a13d5e6f6b500be969ef81/server.jar"

    try:
        response = requests.get(url)
        if response.status_code == 200:
            with open(jar_file_path, 'wb') as f:
                f.write(response.content)
            print(f"Downloaded Minecraft server to '{jar_file_path}'")
        else:
            print(f"Failed to download Minecraft server. Status code: {response.status_code}")
            return
    except requests.exceptions.RequestException as e:
        print(f"Error downloading Minecraft server: {e}")
        return

    # Run the server.jar in its folder
    try:
        file_name = os.path.join(minecraft_folder, "eula.txt")
        content = "#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA).\n#Thu Sep 11 18:22:47 PDT 2025\neula=true"

        with open(file_name, 'w') as file:  
            file.write(content)


        file_name = os.path.join(minecraft_folder, "ops.json")

        content = [
            {
                "uuid": "09062807-bbdf-415a-bb9a-c19af04bf3a0",
                "name": "Meggy_Mode",
                "level": 4,
                "bypassesPlayerLimit": False
            }
        ]
        
        with open(file_name, "w", encoding="utf-8") as f:
            json.dump(content, f, indent=2)

        global sldrVal
        subprocess.Popen(["java", "-Xms2g", "-Xmx" + str(sldrVal) + "m", "-jar", jar_file_path], cwd=minecraft_folder)
        print(f"Running Minecraft server from '{minecraft_folder}'")
        
    except Exception as e:
        print(f"Failed to run Minecraft server: {e}")

import tkinter as tk

# --- Functions for slider/entry ---


# --- Example placeholder functions for server actions ---
def download_unzip_and_run():
    download_extract_and_run_mindustry()

def run_minecraft():
    download_and_run_minecraft()

# --- GUI setup ---
root = tk.Tk()
root.title("Aiden's Server Launcher")

tk.Label(root, text="Simple Server Downloader and Launcher").pack(pady=5, padx=20)

#tk.Button(root, text="Download & Run Mindustry Server", command=download_unzip_and_run).pack(pady=10)
tk.Button(root, text="Download & Run Minecraft Server", command=run_minecraft).pack(pady=10)

# --- Slider + Entry setup ---
tk.Label(root, text="Ram Allocation For Servers").pack(pady=(20,5))

entry_var = tk.StringVar()
entry_var.trace_add('write', entry_to_slider)  # update slider when entry changes

slider = tk.Scale(root, from_=4000, to=8000, orient='horizontal', command=slider_to_entry, resolution=500)
slider.pack(pady=5)

entry = tk.Entry(root, textvariable=entry_var)
entry.pack(pady=5)

# Initialize with slider value
slider.set(50)
entry_var.set("4000")

root.mainloop()
