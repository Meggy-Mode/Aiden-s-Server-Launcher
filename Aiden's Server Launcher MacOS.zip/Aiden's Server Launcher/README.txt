To run the program click Run-Settup

This will start the instalation procces of python (required for the gui)

It will prompt you for your password, input the password into the console / terminal and hit enter

After the download is finished the launcher gui will pop up and you can click the start minecraft server button

The slider is for ram allocated for the server, 4000 is minimum and 8000 is maximum